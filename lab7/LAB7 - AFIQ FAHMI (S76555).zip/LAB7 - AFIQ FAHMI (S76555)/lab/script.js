let index = 0;
const slides = document.getElementsByClassName("slide");

function showSlides() {
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    index++;
    if (index > slides.length) index = 1;
    slides[index - 1].style.display = "block";
    setTimeout(showSlides, 3000);
}
showSlides();

let width = 0;
const bar = document.getElementById("progress-bar");
setInterval(() => {
    if (width < 100) {
        width++;
        bar.style.width = width + "%";
    }
}, 50);

function toggleContent() {
    const content = document.getElementById("content");
    content.classList.toggle("hidden");
}